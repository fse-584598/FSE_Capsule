export class SearchRequest {
    TaskName : string;
    ParentTask : string;
    PriorityFrom : number;
    PriorityTo : number;
    StartDate : Date;
    EndDate : Date;
}
