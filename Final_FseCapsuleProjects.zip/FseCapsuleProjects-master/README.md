# FSE_Projects


git init
git config --global  user.email "<email address>"
git config --global  user.name "<user name>"
git clone "https://github.com/604780/FseCapsuleProjects.git"
git add -A
git commit -m "<message>"
git push -u origin master