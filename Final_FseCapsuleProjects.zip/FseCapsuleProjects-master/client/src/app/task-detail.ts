import { Task } from "./task";

export class TaskDetail extends Task {
    Parent_Task : string;
}
