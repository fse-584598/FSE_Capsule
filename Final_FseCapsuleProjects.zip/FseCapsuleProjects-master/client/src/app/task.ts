export class Task {

    Task_Id : number;
    Task_Name : string;
    Parent_Id : number;
    Priority : number;
    Start_Date : Date;
    End_Date : Date;
}
