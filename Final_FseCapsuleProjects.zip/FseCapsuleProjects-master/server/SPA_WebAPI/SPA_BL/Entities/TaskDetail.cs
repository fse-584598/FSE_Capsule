﻿namespace SPA_BL
{
    public class TaskDetail : SPA_DL.Task
    {
        public string Parent_Task { get; set; }
    }    
}
