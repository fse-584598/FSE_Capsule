import { Component, OnInit } from '@angular/core';
import { TaskDetail } from 'src/app/task-detail';
import {Task } from 'src/app/task';
import { SearchRequest } from 'src/app/search-request';
import { TaskManagerService } from '../task-manager.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {

  tasks : Task[];
  search : SearchRequest;

  constructor(private taskservice: TaskManagerService, private _router: Router) {
    this.search = new SearchRequest();
   }

  ngOnInit() {
      this.getTasks();  
  }

  getTasks() : void
  {
    this.tasks = this.taskservice.getTasks();
  }

  onEditTask(taskid: number)
  {
     this._router.navigateByUrl("/edittask/" + taskid);
  }

  onEndTask(taskid: number)
  {
     
  }

}
