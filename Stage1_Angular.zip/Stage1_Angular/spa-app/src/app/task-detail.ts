import { Task } from "src/app/task";

export class TaskDetail extends Task {
    Parent_Task : string;
}
